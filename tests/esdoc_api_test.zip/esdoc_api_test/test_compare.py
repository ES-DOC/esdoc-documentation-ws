"""
    test
    ~~~~~~~~~~~

    A set of unit tests over ES-DOC compare api.

    :copyright: (c) 2013 by ES-DOCumentation.

"""

from esdoc_api_test.test_comparator_c1 import TestCompare_C1
