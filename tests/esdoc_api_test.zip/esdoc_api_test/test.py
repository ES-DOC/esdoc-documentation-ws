"""
    test
    ~~~~~~~~~~~

    A set of unit tests over ES-DOC api.

    :copyright: (c) 2013 by ES-DOCumentation.

"""

# Module imports.
from esdoc_api_test.test_compare import *
from esdoc_api_test.test_query import *


