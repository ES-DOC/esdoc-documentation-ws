"""
.. module:: prodiguer_shared_tests.__init__.py

   :copyright: @2013 Institute Pierre Simon Laplace (http://esdocumentation.org)
   :license: GPL / CeCILL
   :platform: Unix
   :synopsis: Top level package intializer.

.. moduleauthor:: Institute Pierre Simon Laplace (ES-DOC) <dev@esdocumentation.org>

"""

# Module imports.
import os
import ConfigParser

import prodiguer_shared.repo.session as session
import prodiguer_shared_tests.test_utils as test_utils



# Config constants.
_CONFIG_FILENAME = "config.ini"
_CONFIG_SECTION = "prodiguer_shared_tests"
_CONFIG_ITEM_REPO_URL = "repo.url"


# Initialise config.
_cfg = ConfigParser.ConfigParser()
_cfg.read(os.path.dirname(os.path.abspath(__file__)) + "/" + _CONFIG_FILENAME)



def setup_package():
    print "IPSL PRODIGUER :: Initialising repo session"
    session.start(_cfg.get(_CONFIG_SECTION, _CONFIG_ITEM_REPO_URL))


def teardown_package():
    session.end()
    print "IPSL PRODIGUER :: Ended repo session"

